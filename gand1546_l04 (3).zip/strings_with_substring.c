#include "functions.h"

void strings_with_substring(strings_array *data, char *substr) {
    printf("Matching strings:\n");
    for (int i = 0; i < data->lines; i++) {
        if (strstr(data->strings[i], substr)) {
            printf("%s\n", data->strings[i]);
        }
    }
}
