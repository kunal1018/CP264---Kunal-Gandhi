#include "functions.h"

strings_array* initialize_strings_array(const int capacity) {
    strings_array *data = malloc(sizeof *data);
    if (data == NULL) {
        return NULL;
    }
    data->strings = malloc(capacity * sizeof *data->strings);
    if (data->strings == NULL) {
        free(data);
        return NULL;
    }
    data->capacity = capacity;
    data->lines = 0;
    return data;
}

void free_strings_array(strings_array **data) {
    if (*data != NULL) {
        for (int i = 0; i < (*data)->lines; i++) {
            free((*data)->strings[i]);
        }
        free((*data)->strings);
        free(*data);
        *data = NULL;
    }
}

int read_strings(strings_array *data, FILE *fp) {
    int lines = 0;
    char line[MAX_LINE];
    int length = 0;

    while (fgets(line, sizeof line, fp) != NULL) {
        if (lines < data->capacity) {
            length = strcspn(line, "\r\n");
            line[length] = '\0';

            data->strings[lines] = malloc(length + 1);
            if (data->strings[lines] == NULL) {
                return MALLOC_FAILED;
            }
            strcpy(data->strings[lines], line);
            lines++;
        } else {
            return TOO_MANY_LINES;
        }
    }

    data->lines = lines;
    return lines;
}
