#include "queue_linked.h"

// Initializes a new queue and returns its pointer
queue_linked* queue_initialize() {
    queue_linked *queue = malloc(sizeof(queue_linked));
    if (queue) {
        queue->front = NULL;
        queue->rear = NULL;
        queue->count = 0;
    }
    return queue;
}

// Frees all memory associated with the queue
void queue_free(queue_linked **source) {
    while (!queue_empty(*source)) {
        data_ptr item;
        queue_remove(*source, &item);
        data_free(&item);
    }
    free(*source);
    *source = NULL;
}

// Returns true if the queue is empty
bool queue_empty(const queue_linked *source) {
    return source->count == 0;
}

// Inserts a new item at the rear of the queue
bool queue_insert(queue_linked *source, data_ptr item) {
    queue_node *new_node = malloc(sizeof(queue_node));
    if (new_node == NULL) return false;

    new_node->item = item;
    new_node->next = NULL;

    if (queue_empty(source)) {
        source->front = source->rear = new_node;
    } else {
        source->rear->next = new_node;
        source->rear = new_node;
    }
    source->count++;
    return true;
}

// Returns the item at the front of the queue without removing it
bool queue_peek(const queue_linked *source, data_ptr item) {
    if (queue_empty(source)) return false;
    data_copy(item, source->front->item);
    return true;
}

// Removes and returns the item at the front of the queue
bool queue_remove(queue_linked *source, data_ptr *item) {
    if (queue_empty(source)) return false;

    queue_node *temp_node = source->front;
    *item = temp_node->item;
    source->front = temp_node->next;
    if (source->front == NULL) {
        source->rear = NULL;
    }
    free(temp_node);
    source->count--;
    return true;
}

// Prints all items in the queue from front to rear
void queue_print(const queue_linked *source) {
    char string[DATA_STRING_SIZE]; // Assuming DATA_STRING_SIZE is defined as 80 in data.h
    queue_node *current = source->front;

    while (current != NULL) {
        if (data_string(string, sizeof string, current->item) >= 0) {
            printf("%s\n", string);
        }
        current = current->next;
    }
}
