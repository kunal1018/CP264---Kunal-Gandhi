#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "mystring.h"
#include "myword.h"

#define MAX_LINE_LEN 1000
#define MAX_WORDS 1000

/**
 * Loads words from a file into the dictionary.
 * Stores words separated by commas.
 */
int create_dictionary(FILE *fp, char *dictionary) {
    if (!fp || !dictionary) return 0;
    
    char line[MAX_LINE_LEN];
    char delimiters[] = " .,\n\t\r";
    char *token;
    int count = 0;
    
    while (fgets(line, MAX_LINE_LEN, fp)) {
        str_lower(line);
        str_trim(line);
        
        token = strtok(line, delimiters);
        while (token) {
            strcat(dictionary, token);
            strcat(dictionary, ",");
            count++;
            token = strtok(NULL, delimiters);
        }
    }
    return count;
}

/**
 * Checks if a given word is present in the dictionary.
 */
BOOLEAN contain_word(char *dictionary, char *word) {
    if (!dictionary || !word || *word == '\0') return FALSE;
    
    char temp[25] = ",";
    strcat(temp, word);
    strcat(temp, ",");
    
    return strstr(dictionary, temp) ? TRUE : FALSE;
}

/**
 * Processes words from a text file and counts occurrences.
 */
WORDSTATS process_words(FILE *fp, WORD *words, char *dictionary) {
    WORDSTATS ws = {0};
    char line[MAX_LINE_LEN];
    char delimiters[] = " .,\n\t\r";
    char *word_token;

    while (fgets(line, MAX_LINE_LEN, fp)) {
        ws.line_count++;
        str_lower(line);
        str_trim(line);

        word_token = strtok(line, delimiters);
        while (word_token) {
            ws.word_count++;

            if (!contain_word(dictionary, word_token)) {
                int j = 0;
                while (j < ws.keyword_count && strcmp(word_token, words[j].word) != 0) j++;

                if (j < ws.keyword_count) {
                    words[j].count++;
                } else {
                    strcpy(words[j].word, word_token);
                    words[j].count = 1;
                    ws.keyword_count++;
                }
            }
            word_token = strtok(NULL, delimiters);
        }
    }
    return ws;
}
