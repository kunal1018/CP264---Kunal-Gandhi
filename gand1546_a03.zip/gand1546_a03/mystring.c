#include "mystring.h"
#include <stdio.h>
#include <ctype.h>
#include <string.h>

/**
 * Counts the number of words in the given string.
 */
int str_words(char *s) {
    if (!s) return 0;
    
    int count = 0, in_word = 0;

    while (*s) {
        if ((*s >= 'A' && *s <= 'Z') || (*s >= 'a' && *s <= 'z')) { 
            if (!in_word) {
                count++;
                in_word = 1;
            }
        } else if (*s == ' ' || *s == '\t' || *s == ',' || *s == '.') {
            in_word = 0;
        }
        s++;
    }
    return count;
}

/**
 * Converts all uppercase letters to lowercase in the given string.
 */
int str_lower(char *s) {
    if (!s) return 0;
    
    int changes = 0;
    
    while (*s) {
        if (*s >= 'A' && *s <= 'Z') {
            *s = tolower(*s);
            changes++;
        }
        s++;
    }
    return changes;
}

/**
 * Trims unnecessary spaces from the given string.
 */
void str_trim(char *s) {
    if (!s) return;
    
    char *p = s, *dp = s;
    int in_space = 1;

    while (*p) {
        if (*p != ' ' || (p > s && *(p - 1) != ' ')) { 
            *dp++ = *p;
        }
        p++;
    }
    
    // Remove trailing space
    if (dp > s && *(dp - 1) == ' ') {
        dp--;
    }
    
    *dp = '\0';
}
