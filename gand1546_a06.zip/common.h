/*--------------------------------------------------
 File:    common.h
 About:   node structure and functions for linked list queue and stack
 Author:  HBF
 Version: 2025-02-13
 --------------------------------------------------
 */ 
#ifndef COMMON_H
#define COMMON_H

typedef struct node {
    int data;   // represent operand, operator, or parenthesis according to the type
    int type;   // 0:operand; 1:operator; 2:left parenthesis; 3:right parenthesis
    struct node *next;
} NODE;

NODE *new_node(int data, int type);
void clean(NODE **npp);
void display(NODE *np);
int mytype(char c);
int priority(char op);

#endif
