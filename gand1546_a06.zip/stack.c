#include "stack.h"
#include <stdlib.h>

void push(STACK *sp, NODE *np) {
    if (sp == NULL || np == NULL) return;
    np->next = sp->top;
    sp->top = np;
    sp->length++;
}

NODE *pop(STACK *sp) {
    if (sp == NULL || sp->top == NULL) return NULL;
    NODE *temp = sp->top;
    sp->top = temp->next;
    sp->length--;
    temp->next = NULL;
    return temp;
}

void clean_stack(STACK *sp) {
    if (sp == NULL) return;
    clean(&(sp->top));
    sp->length = 0;
}
