/*--------------------------------------------------
 File:     common.c
 About:    implementation of common.h
 Author:   HBF
 Version:  2025-02-13
 --------------------------------------------------
 */

#include <stdio.h>
#include <stdlib.h>
#include "common.h"

NODE *new_node(int data, int type) {
    NODE *np = (NODE *) malloc(sizeof(NODE));
    if (np == NULL) {
        return NULL;  // Check for failed memory allocation
    }
    np->data = data;
    np->type = type;
    np->next = NULL;
    return np;
}

void clean(NODE **npp) {
    NODE *tmp, *np = *npp;
    while (np) {
        tmp = np;
        np = np->next;
        free(tmp);
    }
    *npp = NULL;
}

void display(NODE *np) {
    while (np) {
        if (np->type == 0) {
            printf("%d ", np->data);
        } else {
            printf("%c ", np->data);
        }
        np = np->next;
    }
    printf("\n");
}

int mytype(char c) {
    if (c >= '0' && c <= '9') return 0;
    if (c == '+' || c == '-' || c == '*' || c == '/') return 1;
    if (c == '(') return 2;
    if (c == ')') return 3;
    return -1;
}

int priority(char op) {
    if (op == '*' || op == '/') return 2;
    if (op == '+' || op == '-') return 1;
    return 0;
}
