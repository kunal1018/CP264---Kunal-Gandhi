#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "queue.h"
#include "stack.h"
#include "expression.h"

QUEUE infix_to_postfix(char *infixstr) {
    char *p = infixstr;
    QUEUE queue = {0}; // result postfix expression in queue
    STACK stack = {0}; // auxiliary stack
    int sign = 1, num = 0;

    while (*p) { // expression string traversal
        if (*p == '-' && (p == infixstr || *(p - 1) == '(')) { // determine negative sign
            sign = -1;
        } else if (mytype(*p) == 0) { // operand (digit)
            num = *p - '0';
            while ((*(p + 1) >= '0' && *(p + 1) <= '9')) {
                num = num * 10 + (*(p + 1) - '0');
                p++;
            }
            enqueue(&queue, new_node(sign * num, 0));
            sign = 1;
        } else if (mytype(*p) == 1) { // operator
            while (stack.top != NULL && stack.top->type == 1 && priority(stack.top->data) >= priority(*p)) {
                enqueue(&queue, pop(&stack));
            }
            push(&stack, new_node(*p, 1));
        } else if (mytype(*p) == 2) { // left parenthesis '('
            push(&stack, new_node(*p, 2));
        } else if (mytype(*p) == 3) { // right parenthesis ')'
            while (stack.top != NULL && stack.top->type != 2) {
                enqueue(&queue, pop(&stack));
            }
            if (stack.top != NULL && stack.top->type == 2) {
                free(pop(&stack)); // remove '(' from stack
            }
        }
        p++;
    }

    // Pop remaining operators from stack to queue
    while (stack.top != NULL) {
        enqueue(&queue, pop(&stack));
    }

    return queue;
}

int evaluate_postfix(QUEUE queue) {
    NODE *p = queue.front;
    STACK stack = {0}; // auxiliary stack for postfix evaluation
    int type = 0;

    while (p) { // traverse the queue linked list
        type = p->type;
        if (type == 0) { // operand
            push(&stack, new_node(p->data, 0));
        } else if (type == 1) { // operator
            int operator = p->data;
            NODE *operand2 = pop(&stack);
            NODE *operand1 = pop(&stack);

            int result = 0;
            switch (operator) {
                case '+': result = operand1->data + operand2->data; break;
                case '-': result = operand1->data - operand2->data; break;
                case '*': result = operand1->data * operand2->data; break;
                case '/': result = operand1->data / operand2->data; break;
            }
            push(&stack, new_node(result, 0));
            free(operand1);
            free(operand2);
        }
        p = p->next;
    }

    int result = stack.top->data;
    clean_stack(&stack);
    return result;
}

int evaluate_infix(char *infixstr) {
    QUEUE postfix_queue = infix_to_postfix(infixstr);
    int result = evaluate_postfix(postfix_queue);
    clean_queue(&postfix_queue);
    return result;
}