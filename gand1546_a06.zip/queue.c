#include "queue.h"
#include <stdlib.h>

void enqueue(QUEUE *qp, NODE *np) {
    if (qp == NULL || np == NULL) return;
    np->next = NULL;
    if (qp->rear != NULL) qp->rear->next = np;
    else qp->front = np;
    qp->rear = np;
    qp->length++;
}

NODE *dequeue(QUEUE *qp) {
    if (qp == NULL || qp->front == NULL) return NULL;
    NODE *temp = qp->front;
    qp->front = temp->next;
    if (qp->front == NULL) qp->rear = NULL;
    qp->length--;
    temp->next = NULL;
    return temp;
}

void clean_queue(QUEUE *qp) {
    if (qp == NULL) return;
    clean(&(qp->front));
    qp->rear = NULL;
    qp->length = 0;
}
