#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avl.h"

// Helper function to get the maximum of two integers
int max(int a, int b) {
    return (a > b) ? a : b;
}

// Function to get the height of a node
int height(AVLNODE *root) {
    if (root == NULL) return 0;
    return root->height;
}

// Function to calculate the balance factor of a node
int balance_factor(AVLNODE *np) {
    if (np == NULL) return 0;
    return height(np->left) - height(np->right);
}

// Function to perform a left rotation
AVLNODE *rotate_left(AVLNODE *np) {
    AVLNODE *right_child = np->right;
    AVLNODE *left_grandchild = right_child->left;

    // Perform rotation
    right_child->left = np;
    np->right = left_grandchild;

    // Update heights
    np->height = 1 + max(height(np->left), height(np->right));
    right_child->height = 1 + max(height(right_child->left), height(right_child->right));

    // Return new root
    return right_child;
}

// Function to perform a right rotation
AVLNODE *rotate_right(AVLNODE *root) {
    AVLNODE *left_child = root->left;
    AVLNODE *right_grandchild = left_child->right;

    // Perform rotation
    left_child->right = root;
    root->left = right_grandchild;

    // Update heights
    root->height = 1 + max(height(root->left), height(root->right));
    left_child->height = 1 + max(height(left_child->left), height(left_child->right));

    // Return new root
    return left_child;
}

// Function to insert a node into the AVL tree
void avl_insert(AVLNODE **rootp, RECORD data) {
    if (*rootp == NULL) {
        AVLNODE *np = (AVLNODE *)malloc(sizeof(AVLNODE));
        if (np) {
            np->data = data;
            np->height = 1;
            np->left = NULL;
            np->right = NULL;
        }
        *rootp = np;
    } else {
        AVLNODE *root = *rootp;
        int cmp = strcmp(data.name, root->data.name);
        if (cmp < 0) {
            avl_insert(&root->left, data);  // Insert into left subtree
        } else if (cmp > 0) {
            avl_insert(&root->right, data); // Insert into right subtree
        } else {
            // Duplicate found, do not insert
            return;
        }

        // Update height of this ancestor node
        root->height = 1 + max(height(root->left), height(root->right));

        // Get the balance factor to check if this node became unbalanced
        int balance = balance_factor(root);

        // Perform rotations if necessary
        if (balance > 1 && strcmp(data.name, root->left->data.name) < 0) {
            *rootp = rotate_right(root);
        } else if (balance < -1 && strcmp(data.name, root->right->data.name) > 0) {
            *rootp = rotate_left(root);
        } else if (balance > 1 && strcmp(data.name, root->left->data.name) > 0) {
            root->left = rotate_left(root->left);
            *rootp = rotate_right(root);
        } else if (balance < -1 && strcmp(data.name, root->right->data.name) < 0) {
            root->right = rotate_right(root->right);
            *rootp = rotate_left(root);
        }
    }
}

// Function to delete a node from the AVL tree
void avl_delete(AVLNODE **rootp, char *key) {
    if (*rootp == NULL) return;

    AVLNODE *root = *rootp;
    int cmp = strcmp(key, root->data.name);
    if (cmp < 0) {
        avl_delete(&root->left, key);
    } else if (cmp > 0) {
        avl_delete(&root->right, key);
    } else {
        // Node to be deleted found
        if (root->left == NULL || root->right == NULL) {
            AVLNODE *temp = root->left ? root->left : root->right;
            if (temp == NULL) {
                temp = root;
                *rootp = NULL;
            } else {
                *rootp = temp;
            }
            free(temp);
        } else {
            // Node with two children: Get the inorder successor
            AVLNODE *temp = root->right;
            while (temp->left != NULL) {
                temp = temp->left;
            }
            // Copy the inorder successor's data to this node
            root->data = temp->data;
            // Delete the inorder successor
            avl_delete(&root->right, temp->data.name);
        }
    }

    // If the tree had only one node, return
    if (*rootp == NULL) return;

    // Update height of the current node
    root = *rootp;
    root->height = 1 + max(height(root->left), height(root->right));

    // Get the balance factor to check if this node became unbalanced
    int balance = balance_factor(root);

    // Perform rotations if necessary
    if (balance > 1 && balance_factor(root->left) >= 0) {
        *rootp = rotate_right(root);
    } else if (balance > 1 && balance_factor(root->left) < 0) {
        root->left = rotate_left(root->left);
        *rootp = rotate_right(root);
    } else if (balance < -1 && balance_factor(root->right) <= 0) {
        *rootp = rotate_left(root);
    } else if (balance < -1 && balance_factor(root->right) > 0) {
        root->right = rotate_right(root->right);
        *rootp = rotate_left(root);
    }
}

// Function to search for a node in the AVL tree
AVLNODE *avl_search(AVLNODE *root, char *key) {
    if (root == NULL) return NULL;

    int cmp = strcmp(key, root->data.name);
    if (cmp < 0) {
        return avl_search(root->left, key);
    } else if (cmp > 0) {
        return avl_search(root->right, key);
    } else {
        return root;
    }
}

// Function to clean the AVL tree
void avl_clean(AVLNODE **rootp) {
    if (*rootp == NULL) return;
    avl_clean(&(*rootp)->left);
    avl_clean(&(*rootp)->right);
    free(*rootp);
    *rootp = NULL;
}