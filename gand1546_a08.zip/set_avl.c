#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avl.h"
#include "set_avl.h"

/* Returns the number of elements in the set. */
int set_size(SET *s) {
    return s->size;
}

/* Returns 1 if the set contains the element e; otherwise, returns 0. */
int set_contain(SET *s, char *e) {
    return (avl_search(s->root, e) != NULL) ? 1 : 0;
}

/* Adds the element e to the set if it is not already present. */
void set_add(SET *s, char *e) {
    if (!set_contain(s, e)) {
        RECORD r = {0};
        strcpy(r.name, e);
        avl_insert(&(s->root), r);
        s->size++;
    }
}

/* Removes the element e from the set if it is present. */
void set_remove(SET *s, char *e) {
    if (set_contain(s, e)) {
        avl_delete(&(s->root), e);
        s->size--;
    }
}

/* Clears the set, resetting its size to 0 and cleaning the AVL tree. */
void set_clean(SET *s) {
    avl_clean(&(s->root));
    s->size = 0;
}