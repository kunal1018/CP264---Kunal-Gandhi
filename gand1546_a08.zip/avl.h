#ifndef AVL_H
#define AVL_H

typedef struct record {
    char name[20];
    float score;
} RECORD;

typedef struct avlnode AVLNODE;

struct avlnode {
    RECORD data;
    int height;
    AVLNODE *left;
    AVLNODE *right;
};

// Function prototypes
void avl_insert(AVLNODE **rootp, RECORD data);  // Insert a node into the AVL tree
void avl_delete(AVLNODE **rootp, char *key);    // Delete a node from the AVL tree
AVLNODE *avl_search(AVLNODE *root, char *key);  // Search for a node in the AVL tree
void avl_clean(AVLNODE **rootp);                // Clean the AVL tree (free all memory)
int height(AVLNODE *root);                      // Get the height of a node
int balance_factor(AVLNODE *np);                // Calculate the balance factor of a node
AVLNODE *rotate_left(AVLNODE *np);              // Perform a left rotation
AVLNODE *rotate_right(AVLNODE *root);           // Perform a right rotation

#endif