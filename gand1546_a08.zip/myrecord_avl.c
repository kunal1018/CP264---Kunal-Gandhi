#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "avl.h"
#include "myrecord_avl.h"

/* Helper function to recursively merge AVL trees */
void merge_helper(AVLNODE **dest_rootp, AVLNODE *source_node) {
    if (source_node) {
        // Insert the current node from the source tree into the destination tree
        avl_insert(dest_rootp, source_node->data);

        // Recursively merge the left and right subtrees
        merge_helper(dest_rootp, source_node->left);
        merge_helper(dest_rootp, source_node->right);
    }
}

/* Merge source AVL tree into destination AVL tree. No change to source tree. */
void avl_merge(AVLNODE **dest_rootp, AVLNODE **source_rootp) {
    if (*source_rootp == NULL) return; // Nothing to merge
    merge_helper(dest_rootp, *source_rootp);
}

/* Merge source AVLDS to destination AVLDS, using aggregation algorithm to compute stats. */
void avlds_merge(AVLDS *dest, AVLDS *source) {
    if (source->count == 0) return; // Nothing to merge

    // Merge the AVL trees
    avl_merge(&(dest->root), &(source->root));

    // Compute the new count, mean, and stddev using aggregation formulas
    int count1 = dest->count;
    int count2 = source->count;
    float mean1 = dest->mean;
    float mean2 = source->mean;
    float stddev1 = dest->stddev;
    float stddev2 = source->stddev;

    dest->count = count1 + count2;
    dest->mean = (mean1 * count1 + mean2 * count2) / (count1 + count2);

    float sum1 = (stddev1 * stddev1 + mean1 * mean1) * count1;
    float sum2 = (stddev2 * stddev2 + mean2 * mean2) * count2;
    float new_stddev = sqrt((sum1 + sum2) / (count1 + count2) - dest->mean * dest->mean);
    dest->stddev = new_stddev;

    // Clean the source AVLDS
    avlds_clean(source);
}

/* Clean the AVL tree and reset count, mean, and stddev to 0. */
void avlds_clean(AVLDS *ds) {
    avl_clean(&ds->root);
    ds->count = 0;
    ds->mean = 0;
    ds->stddev = 0;
}

/* Add a record to the AVLDS. */
void add_record(AVLDS *ds, RECORD data) {
    if (avl_search(ds->root, data.name) == NULL) {
        avl_insert(&(ds->root), data);

        // Update count, mean, and stddev
        int count = ds->count;
        float mean = ds->mean;
        float stddev = ds->stddev;

        ds->count = count + 1;
        ds->mean = (mean * count + data.score) / (count + 1.0);
        ds->stddev = sqrt((data.score * data.score) / (count + 1.0) + 
                     (stddev * stddev + mean * mean) * (count / (count + 1.0)) - 
                     ds->mean * ds->mean);
    } else {
        printf("Record already exists.\n");
    }
}

/* Remove a record from the AVLDS by name. */
void remove_record(AVLDS *ds, char *name) {
    AVLNODE *np = avl_search(ds->root, name);
    if (np != NULL) {
        float score = np->data.score;
        avl_delete(&(ds->root), name);

        // Update count, mean, and stddev
        int count = ds->count;
        float mean = ds->mean;
        float stddev = ds->stddev;

        ds->count = count - 1;
        if (count >= 3) {
            ds->mean = (mean * count - score) / (count - 1.0);
            ds->stddev = sqrt((stddev * stddev + mean * mean) * (count / (count - 1.0)) - 
                         (score * score) / (count - 1.0) - 
                         ds->mean * ds->mean);
        } else if (count == 2) {
            ds->mean = mean * count - score;
            ds->stddev = 0;
        } else {
            ds->mean = 0;
            ds->stddev = 0;
        }
    } else {
        printf("Record does not exist.\n");
    }
}