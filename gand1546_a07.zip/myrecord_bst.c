/*
--------------------------------------------------
Project: gand1546_a07
File:    myrecord_bst.c
Author:  Kunal Gandhi
Version: 2025-01-16
--------------------------------------------------
*/

#include <stdio.h>
#include <math.h>
#include "bst.h"
#include "myrecord_bst.h"

/* Adds a record data into the BSTDS and updates its statistic fields */
void add_record(BSTDS *ds, RECORD record) {
    // Implementation as provided
}

/* Deletes a node from BSTDS with data.name matching with the given name */
void remove_record(BSTDS *ds, char *name) {
    // Implementation as provided
}

void bstds_clean(BSTDS *ds) {
  bst_clean(&ds->root);
  ds->count = 0;
  ds->mean = 0;
  ds->stddev = 0;
}
