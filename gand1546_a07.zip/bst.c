/*
--------------------------------------------------
Project: gand1546_a07
File:    bst.c
Author:  Kunal Gandhi
Version: 2025-01-16
--------------------------------------------------
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "bst.h"

// Function to create a new BST node with given data
BSTNODE *bst_node(RECORD data) {
    BSTNODE *np = (BSTNODE *)malloc(sizeof(BSTNODE));
    if (np) {
        memcpy(np, &data, sizeof(BSTNODE));  // Copy data into node
        np->left = NULL;
        np->right = NULL;
    }
    return np;
}

// Function to search a node by key in BST
BSTNODE *bst_search(BSTNODE *root, char *key) {
    if (root == NULL || strcmp(root->data.name, key) == 0)
        return root;
    if (strcmp(key, root->data.name) < 0)
        return bst_search(root->left, key);
    else
        return bst_search(root->right, key);
}

// Function to insert a new node with given data into BST
void bst_insert(BSTNODE **rootp, RECORD data) {
    if (*rootp == NULL) {
        *rootp = bst_node(data);
    } else if (strcmp(data.name, (*rootp)->data.name) < 0) {
        bst_insert(&((*rootp)->left), data);
    } else {
        bst_insert(&((*rootp)->right), data);
    }
}

// Function to delete a node by key from BST
void bst_delete(BSTNODE **rootp, char *key) {
    if (*rootp == NULL) return;

    if (strcmp(key, (*rootp)->data.name) < 0) {
        bst_delete(&((*rootp)->left), key);
    } else if (strcmp(key, (*rootp)->data.name) > 0) {
        bst_delete(&((*rootp)->right), key);
    } else {
        if ((*rootp)->left == NULL || (*rootp)->right == NULL) {
            BSTNODE *temp = (*rootp)->left ? (*rootp)->left : (*rootp)->right;
            free(*rootp);
            *rootp = temp;
        } else {
            BSTNODE *temp = extract_smallest_node(&((*rootp)->right));
            (*rootp)->data = temp->data;  // Swap data
            free(temp);
        }
    }
}

// Function to perform in-order traversal on a BST
void bst_inorder(BSTNODE *root) {
    if (root) {
        bst_inorder(root->left);
        printf("%s: %.2f\n", root->data.name, root->data.score);
        bst_inorder(root->right);
    }
}

// Function to clean up the BST and free memory
void bst_clean(BSTNODE **rootp) {
    if (*rootp) {
        bst_clean(&((*rootp)->left));
        bst_clean(&((*rootp)->right));
        free(*rootp);
        *rootp = NULL;
    }
}

// Function to extract the smallest node from the BST
BSTNODE *extract_smallest_node(BSTNODE **rootp) {
    BSTNODE *parent = NULL;
    BSTNODE *current = *rootp;
    while (current && current->left) {
        parent = current;
        current = current->left;
    }
    if (parent) {
        parent->left = current->right;
    } else {
        *rootp = current->right;
    }
    current->left = current->right = NULL;
    return current;
}
