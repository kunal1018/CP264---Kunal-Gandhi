/*
--------------------------------------------------
Project: gand1546_a07
File:    queue_stack.h
Author:  Kunal Gandhi
Version: 2025-01-16
--------------------------------------------------
*/

#ifndef QUEUE_STACK_H
#define QUEUE_STACK_H

typedef struct node {
    void *data;
    struct node *next;
} NODE;

typedef struct queue {
    NODE *front, *rear;
} QUEUE;

void enqueue(QUEUE *qp, void *data);
void *dequeue(QUEUE *qp);
void clean_queue(QUEUE *qp);

typedef struct stack {
    NODE *top;
} STACK;

void push(STACK *sp, void *data);
void *pop(STACK *sp);
void clean_stack(STACK *sp);

#endif
