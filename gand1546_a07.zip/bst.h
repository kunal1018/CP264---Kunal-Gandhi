/*
--------------------------------------------------
Project: gand1546_a07
File:    bst.h
Author:  Kunal Gandhi
Version: 2025-01-16
--------------------------------------------------
*/

#ifndef BST_H
#define BST_H

typedef struct record {
  char name[20];
  float score;
} RECORD;

typedef struct bstnode {
  RECORD data;
  struct bstnode *left;
  struct bstnode *right;
} BSTNODE;

// Function prototypes for binary search tree operations
BSTNODE *bst_node(RECORD data);
BSTNODE *bst_search(BSTNODE *root, char *key);
void bst_insert(BSTNODE **rootp, RECORD data);
void bst_delete(BSTNODE **rootp, char *key);
void bst_clean(BSTNODE **rootp);
BSTNODE *extract_smallest_node(BSTNODE **rootp);

// Function prototype for performing in-order traversal on a binary search tree
void bst_inorder(BSTNODE *root);

#endif
