#include <stdio.h>
#include "bst.h"
#include "tree.h"
#include "myrecord_bst.h"
#include "queue_stack.h"

int main() {
    printf("Testing Binary Search Tree Operations...\n");
    BSTNODE *bstRoot = NULL;
    RECORD r1 = {"Alice", 95};
    RECORD r2 = {"Bob", 85};
    RECORD r3 = {"Charlie", 75};

    // Test insertion
    bst_insert(&bstRoot, r1);
    bst_insert(&bstRoot, r2);
    bst_insert(&bstRoot, r3);

    // Test search
    BSTNODE *found = bst_search(bstRoot, "Bob");
    if (found != NULL) {
        printf("Found Bob with score: %.2f\n", found->data.score);
    } else {
        printf("Bob not found.\n");
    }

    // Assume inorder traversal for BST is implemented to display the tree
    printf("Inorder traversal of BST:\n");
    inorder(bstRoot);  // This should match the type expected by inorder in tree.h

    // Clean up
    bst_clean(&bstRoot);

    // Optionally, add tests for tree operations and myrecord_bst operations

    return 0;
}
