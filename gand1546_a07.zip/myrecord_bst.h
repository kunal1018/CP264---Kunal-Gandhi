/*
--------------------------------------------------
Project: gand1546_a07
File:    myrecord_bst.h
Author:  Kunal Gandhi
Version: 2025-01-16
--------------------------------------------------
*/

#ifndef MYRECORD_BST_H
#define MYRECORD_BST_H

#include "bst.h"  // Ensure BSTNODE is defined by including bst.h

typedef struct {
    BSTNODE *root;
    int count;
    float mean;
    float stddev;
} BSTDS;

void add_record(BSTDS *ds, RECORD record);
void remove_record(BSTDS *ds, char *name);
void bstds_clean(BSTDS *ds);

#endif
