/*
 * CP264 - Assignment 4
 * Record Processing Implementation
 * Name: Kunal Gandhi
 * ID: 169051546
 * Email: gand1546@mylaurier.ca
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "myrecord.h"
#include "mysort.h"

// Grade conversion function
GRADE grade(float score) {
    GRADE r = {"F"};
    char g[][3] = {"A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D+", "D", "D-", "F"};
    int b[] = {100, 90, 85, 80, 77, 73, 70, 67, 63, 60, 57, 53, 50, 0};

    for (int i = 0; i < 13; i++) {
        if (score >= b[i + 1]) {
            strcpy(r.letter_grade, g[i]);
            break;
        }
    }
    return r;
}

// Import data from file into dataset array
int import_data(FILE *fp, RECORD *dataset) {
    int count = 0;
    while (fscanf(fp, "%[^,],%f\n", dataset[count].name, &dataset[count].score) == 2) {
        count++;
    }
    return count;
}

// Process data for statistics
STATS process_data(RECORD *dataset, int count) {
    STATS stats = {count, 0, 0, 0};

    // Compute mean
    for (int i = 0; i < count; i++) {
        stats.mean += dataset[i].score;
    }
    stats.mean /= count;

    // Compute standard deviation
    for (int i = 0; i < count; i++) {
        stats.stddev += pow(dataset[i].score - stats.mean, 2);
    }
    stats.stddev = sqrt(stats.stddev / count);

    // Compute median (Sorting dataset correctly before median calculation)
    RECORD *p[count];  // Array of pointers for sorting
    for (int i = 0; i < count; i++) {
        p[i] = &dataset[i];
    }

    // Sort dataset in **ascending** order for correct median calculation
    my_sort((void **)p, 0, count - 1, cmp);

    // Correct Median Calculation (Middle value or average of two middle values)
    if (count % 2 == 0) {
        stats.median = (p[count / 2]->score + p[(count / 2) - 1]->score) / 2;
    } else {
        stats.median = p[count / 2]->score;
    }

    return stats;
}

// Generate report (Ensures correct descending order)
int report_data(FILE *fp, RECORD *dataset, STATS stats) {
    if (stats.count < 1) return 0;

    fprintf(fp, "stats:value\ncount:%d\nmean:%.1f\nstddev:%.1f\nmedian:%.1f\n\n", 
            stats.count, stats.mean, stats.stddev, stats.median);
    fprintf(fp, "name:score,grade\n");

    // Create an array of RECORD pointers to sort without modifying original data
    RECORD *p[stats.count];
    for (int i = 0; i < stats.count; i++) {
        p[i] = &dataset[i];
    }

    // Sort using my_sort() with the fixed cmp() function
    my_sort((void **)p, 0, stats.count - 1, cmp);

    // Print sorted records in descending order
    for (int i = 0; i < stats.count; i++) {
        fprintf(fp, "%s:%.1f,%s\n", p[i]->name, p[i]->score, grade(p[i]->score).letter_grade);
    }

    return 1;
}
