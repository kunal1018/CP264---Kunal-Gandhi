/*
 * CP264 - Assignment 4
 * Sorting Header File
 * Name: Kunal Gandhi
 * ID: 169051546
 * Email: gand1546@mylaurier.ca
 */

#ifndef MYSORT_H
#define MYSORT_H 

void select_sort(void *a[], int left, int right);
void quick_sort(void *a[], int left, int right);
void my_sort(void *a[], int left, int right, int (*cmp)(void*, void*));

// Declare cmp function (defined in mysort.c, used in myrecord.c)
extern int cmp(void *x, void *y);

#endif /* MYSORT_H */
