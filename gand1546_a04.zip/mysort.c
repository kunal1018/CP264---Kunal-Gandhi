/*
 * CP264 - Assignment 4
 * Sorting Implementation
 * Name: Kunal Gandhi
 * ID: 169051546
 * Email: gand1546@mylaurier.ca
 */

#include "mysort.h"
#include "myrecord.h"  // Ensure RECORD struct is recognized

// Swap function
void swap(void **x, void **y) {
    void *temp = *y;
    *y = *x;
    *x = temp;
}

// Corrected Comparison function for RECORD sorting (Descending Order)
int cmp(void *x, void *y) {
    float a = ((RECORD*)x)->score;
    float b = ((RECORD*)y)->score;
    return (b > a) - (b < a);  // Sorting in DESCENDING order
}

// Selection Sort
void select_sort(void *a[], int left, int right) {
    for (int i = left; i <= right; ++i) {
        int min_index = i;
        for (int j = i + 1; j <= right; ++j) {
            if (cmp(a[j], a[min_index]) < 0) {
                min_index = j;
            }
        }
        if (i != min_index) {
            swap(&a[i], &a[min_index]);
        }
    }
}

// Quick Sort
void quick_sort(void *a[], int left, int right) {
    if (left < right) {
        int i = left + 1, j = right;
        while (i <= j) {
            while (i <= right && cmp(a[i], a[left]) <= 0) i++;
            while (j >= left && cmp(a[j], a[left]) > 0) j--;
            if (i < j) swap(&a[i], &a[j]);
        }
        swap(&a[left], &a[j]);
        quick_sort(a, left, j - 1);
        quick_sort(a, j + 1, right);
    }
}

// My Sort (Uses Quick Sort)
void my_sort(void *a[], int left, int right, int (*cmp)(void*, void*)) {
    quick_sort(a, left, right);
}

